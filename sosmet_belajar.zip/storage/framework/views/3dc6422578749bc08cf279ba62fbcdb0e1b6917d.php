<div class="container">
    <h1> Hello World  </h1>
    <?php echo e($nama); ?> <?php echo e($alamat); ?>


    
    

    <ul>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($item); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php echo e($data[2]); ?>


    <ul>
        <?php $__currentLoopData = $dataInisial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($key); ?> : <?php echo e($item); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php echo e($dataInisial["kelas"]); ?>


    <ul>
        <?php $__currentLoopData = $dataObject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($item); ?> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php echo e($dataObject->nama); ?>


    

    <table border="1">
        <thead>
            <td> # </td>
            <td> nama </td>
            <td> kelas </td>
            <td> alamat </td>
        </thead>
        <tbody>
            <?php
                $no = 1 ;
            ?>
            <?php $__currentLoopData = $dataArrayObject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($no++); ?> </td>
                    <td> <?php echo e($item->nama); ?> </td>
                    <td> <?php echo e($item->kelas); ?> </td>
                    <td> <?php echo e($item->alamt); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div><?php /**PATH D:\sosmet_belajar\resources\views/test.blade.php ENDPATH**/ ?>